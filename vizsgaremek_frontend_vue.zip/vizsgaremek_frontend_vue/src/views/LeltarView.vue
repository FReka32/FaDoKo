<template>
    <div class="leltar">
      
    </div>
  </template>
  
  <script>

  
  export default {
    name: 'LeltarView',
    components: {
     
    }
  }
  </script>
  