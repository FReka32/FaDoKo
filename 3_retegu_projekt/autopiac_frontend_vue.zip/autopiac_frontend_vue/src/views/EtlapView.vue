<template>
  <div class="home">
    <Favourites msg="Heti kedvencek"/>
    <Products title="Pizzáink"/>
  </div>
</template>

<script>
// @ is an alias to /src
import HomeGreeting from '@/components/HomeGreeting.vue'
import Favourites from '@/components/Favourites.vue'
import Products from '@/components/Products.vue'

export default {
  name: 'EtlapView',
  components: {
    HomeGreeting,
    Favourites,
    Products
  }
}
</script>




  