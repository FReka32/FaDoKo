import { createStore } from 'vuex'

export default createStore({
  state: {
    logged: false,
    Uid: "",
    userName: "",
    jogosultsag:0,
  },
  getters: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})
