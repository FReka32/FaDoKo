# vizsgaremek_frontend

## Project preparation
```
node -v (install, if not found)
npm -v (install, if not found)
```
## Project setup
```
npm install -g@vue/cli 
In case of permission issues, run this command in PowerShell in administrator mode:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope LocalMachine
npm install bootstrap
npm install bootstrap-icons
npm install axios
npm install sha256
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
